## BIRTHDAY

#### PLAN
- Refer “Happy NewYear”
- Find more examples
- More personal elements


#### TODO
- [x] How to move object
- [x] Search record software
- [x] Coloring effect
- [x] move with certain curve
- [ ] Search ASCII elements of Xi'an


#### END
Already finish the ascii animation of birthday.  
Things should be closed now.  
May bring some joy.  
Dec.19 2018
